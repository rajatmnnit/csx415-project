library(testthat)
library(PhotographerScoring)

test_check("PhotographerScoring")
