library(testthat)

member_guid <- c("abcd", "xyzz")
lr_cc_usage	<- c(0, 10)
lr_cl_usage	<- c(10, 2)
lr_mo_usage	<- c(0, 8)
storage_usage	<- c(0, 800)
ps_usage <- c(3, 0)
stock_usage <- c(0, 0)

df <- data.frame(member_guid, lr_cc_usage, lr_cl_usage, lr_mo_usage, storage_usage, ps_usage, stock_usage)
df
test_that("classify default is gbm", {
  class <- classify(df)
  class
  expect_equal(model.default$method, "gbm")
})

test_that("load.model of gbm is gbm", {
  model.gbm <- load.model("gbm")
  expect_equal(model.gbm$method, "gbm")
})

test_that("load.model of svm is svm", {
  model.svm <- load.model("svm")
  expect_equal(model.svm$method, "svmLinear")
})

test_that("load.model of rf is rf", {
  model.rf <- load.model("rf")
  expect_equal(model.rf$method, "rf")
})
