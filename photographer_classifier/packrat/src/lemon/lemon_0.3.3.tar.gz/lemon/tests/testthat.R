library(testthat)
library(lemon)


if (TRUE) {
  test_check("lemon")
} #else {
#  test_path <- file.path(getwd(), 'tests', 'testthat')
#  testthat:::run_tests('Siccuracy', test_path, filter='test_auxil.R', reporter='summary')
#}