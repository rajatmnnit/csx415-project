library(testthat)
library(PhotographerModels)

test_check("PhotographerModels")
